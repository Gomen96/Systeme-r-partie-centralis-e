/*
*Programme réalisé par KIDJO Darrell licence 2 Génie Logiciel
*Exercice 1 
*darrellkidjo8@gmail.com
*/

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>


int main()
{
	//printf("Je suis le fils 1 et mon PID est : %ld. \n", (long)getpid());
	
	return 0;
}

