/*
*Programme réalisé par KIDJO Darrell licence 2 Génie Logiciel
*Exercice 2 
*darrellkidjo8@gmail.com
*/

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/ipc.h> 
#include <sys/shm.h>  
#include <sys/sem.h>
#include <errno.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>

union semun {
   int  val;    /* Value for SETVAL */
   struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
   unsigned short  *array;  /* Array for GETALL, SETALL */
   struct seminfo  *__buf;  /* Buffer for IPC_INF
                              (Linux-specific) */
};

int main()
{
	pid_t pid1, pid2, pid3;
	int status;
	union semun sem_arg;
	
	// clé pour le semaphore 
    key_t sem_key = ftok("semfile",75);
    // on demande au system de nous créer le semaphore
    int semid = semget(sem_key, 1, 0666|IPC_CREAT);

    // la valeur du semaphore est initialisée à 1
    sem_arg.val = 1;
    if(semctl(semid, 0, SETVAL, sem_arg)==-1){
       perror("semctl");
       exit(1);
    }
    
    // clé pour la mémoire protégée
    key_t key = ftok("shmfile",65);

    int a = 0; // shared data (la variable partagée)

    // On demande au system de creer la memoire partagee 
    int shmid = shmget(key,1024,0666|IPC_CREAT); 
    // on attache la memoire partagee a str
    char *str = (char*) shmat(shmid,(void*)0,0); 
    // ecriture de 0 dans la mémoire partagée
    sprintf(str, "%d", a);

    
	
	pid1 = fork();
	if(pid1<0)
	{
		printf("Erreur de création du fils 1\n");
		pid1 = wait(&status);
		exit(-1);
	}
	if(pid1==0)
	{
		execv("./fils1", NULL);
	}
	else
	{
		pid2 = fork();
		 sleep(4);
		if(pid2<0)
		{
			printf("Erreur de creation du fils 2\n");
			pid1 = wait(&status);
			pid2 = wait(&status);
			exit(-1);
		}
		if(pid2==0)
		{
			execv("./fils1", NULL);
		}
		else
		{
			pid3 = fork();
			sleep(4);
			if(pid3<0)
			{
				printf("Erreur de creation du fils 3\n");
				pid1 = wait(&status);
				pid2 = wait(&status);
				pid3 = wait(&status);
				exit(-1);
			}
			if(pid3==0)
			{
				execv("./fils1", NULL);
			}
			else
			{
				pid1 = wait(&status);
				printf("Je suis le fils 1 de PID : %d et de status : %d \n", pid1, status);
				
				pid2 = wait(&status);
				printf("Je suis le fils 2 de PID : %d et de status : %d \n", pid2, status);
				pid3 = wait(&status);
				printf("Je suis le fils 3 de PID : %d et de status : %d \n", pid3, status);
				
				// on lit la dernière valeur de la variable partagée
                a = atoi(str);
                printf("Valeur Finale de a = %d\n", a);
                //le processus détache str de la mémoire partagée 
                shmdt(str); 
                // destruction de la mémoire 
                shmctl(shmid,IPC_RMID,NULL);
                // des truction du semaphore
                if(semctl(semid, 0, IPC_RMID, NULL) == -1){
                   perror("semctl");
                   exit(1);
                }
			}
		}
	}
	return 0;
}
