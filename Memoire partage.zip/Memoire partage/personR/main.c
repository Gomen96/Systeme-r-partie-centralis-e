#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <stdio.h> 
#include <sys/sem.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

void affiche(int n)
{
		//generer une clée
			key_t key = ftok("shareMemori", 65);
		//generer l'id
			int shmId = shmget(key, 1024, 0666);
		//attacher un pointeur a cette memoire
			char* reader = (char*) shmat(shmId, (void*)0, 0);
		//taille des données
			//int taille = strlen(reader);
			/*for(cmpt=1; cmpt<taille; cmpt++)
			{
				msg[cmptMsg] = reader[cmpt];
				cmptMsg++;
			}*/
		
					if(reader[0] == '0')
					{
						printf("Cette mémoire partagée contient : %s \n", reader);
						reader[0] = '1';
					}

					//detacher le pointeur de cette memoire
						//shmdt(reader);
	
}
int main()
{
	signal(SIGALRM, affiche);
	int i;
				/*else
			printf("Sa marche apparement pas\n");*/
			
		for(i=0; i<10; i++)
		{
			alarm(5);
			pause();
		}
	
	//supprimer mais pas pour le lecteur
	//shmctl(shmId, IPC_RMID, NULL);

	return 0;
}
