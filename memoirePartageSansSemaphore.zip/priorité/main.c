#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <stdio.h> 
#include <sys/sem.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

int main()
{
int valeur;
	key_t shm_key = ftok("shmfile",65); 
	int shmid = shmget(shm_key,1024,0666|IPC_CREAT);
	//sleep(2); 
	char *str = (char*) shmat(shmid,(void*)0,0);
	
	valeur = atoi(str);
	valeur = valeur*1000;
	
	
	sprintf(str, "%d", valeur);
	printf("Valeur selon fils 2 : %s \n", str);
	shmdt(str);
	//shmctl(shmid, IPC_RMID, NULL);
	return 0;
}
