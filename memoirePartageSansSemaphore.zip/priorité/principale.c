#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <stdio.h> 
#include <sys/sem.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

int main()
{
	pid_t pid1, pid2;
	int valeur = 7, status1, status2, test;
	key_t shm_key = ftok("shmfile",65); 
	int shmid = shmget(shm_key,1024,0666|IPC_CREAT); 
	
	char *str = (char*) shmat(shmid,(void*)0,0);
	
	sprintf(str, "%d", valeur);
	
	test = atoi(str);
	pid1 = fork();
	if(pid1<0)
	{
		printf("Erreur de création du fils 1");
	}
	if(pid1 == 0)
	{
		printf("Debut du processus 1");
		execv("./p2", NULL);
	}
	else
	{
		//sleep(2);
		pid2 = fork();
		if(pid2<0)
		{
			printf("Erreur de création du fils 2");
		}
		if(pid2 == 0)
		{
			printf("Debut du processus 2");
			sleep(2);
			execv("./prog1", NULL);
		}
		else
		{
			//sleep(4);
			
			status1 = wait(&status1);
			printf("le fils 1 s'est terminé avec le status %d \n", status1);
			status2 = wait(&status2);
			printf("Le fils 2 s'est terminé avec le status %d \n", status2);
			test = atoi(str);
			printf("La valeur finale est 😎️ : %d\n", test);
		}
	}

	
	shmdt(str);
	shmctl(shmid, IPC_RMID, NULL);
	return 0;
}
